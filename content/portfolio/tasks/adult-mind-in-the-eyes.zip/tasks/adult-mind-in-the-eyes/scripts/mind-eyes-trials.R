# Packages ----------------------------------------------------------------
library(tidyverse)
library(glue)

# Copy Images -------------------------------------------------------------
# walk(list.files(path = "../Mind in the Eyes/Resized_RME_JPEG_files", pattern = ".jpg$",full.names = F), function(x){
#   file.copy(paste0("../Mind in the Eyes/Resized_RME_JPEG_files/", x),to = paste0("img/", x))
# })

# List Images -------------------------------------------------------------
me_images <- list.files("img",full.names = T,pattern = "\\d\\d.jpg$")

cat(paste0("'",me_images,"'"),sep = ",\n")

# Read answers ------------------------------------------------------------
me_answers <- read_csv("data/answers.csv")

# Read definitions --------------------------------------------------------
me_defs <- read_csv("data/definitions.csv") %>% 
  mutate(word     = str_trim(word) %>% str_to_lower(),
         sentence = str_replace(sentence, word, paste0("<b>",word,"</b>")) %>% str_to_sentence())

me_data <- me_answers %>% 
  gather(option, response, -starts_with("answer"), -gender, -img) %>% 
  left_join(me_defs, by = c("response" = "word")) %>% 
  mutate(option = str_replace(option,"choice","choice_")) %>% 
  separate(option, c("option","number")) %>% 
  gather(info, data,-starts_with("answer"), -gender, -img, -number) %>% 
  unite(info, info, number,sep="") %>% 
  spread(info, data) %>% 
  rename_at(vars(starts_with("response")),~str_replace(.,"response","choice")) %>% 
  mutate_at(vars(starts_with("definition")),~str_replace(.,"\'","\'"))

glue_data(
  .open = "(", .close = ")",.na = "",
  me_data %>% arrange(img) %>%  
    filter(img!="P") %>% 
    mutate(path = me_images[1:36]),
  "{stimulus: \"<image src='(path)' width = '700px'><br><br>\", choices: ['(choice0)','(choice1)','(choice2)','(choice3)'], data: {gender: '(gender)', face: (img), answer: (answer_js)}},"
)

glue_data(
  .open = "(", .close = ")",.na = "", .sep = "\n",
  me_data %>% mutate(img = as.numeric(img)) %>% arrange(img) %>%  mutate(row = 1:n()),
  "\"<div class=\'tooltip\'>\" +",
  "\"*definitions*\" +",
  "\"<span class =  \'tooltiptext\'><table>\"+",
  "\"<tr style = 'border-bottom: 1px solid #ccc;'><td><b>(choice0):</b></td><td>(definition0)</td></tr>\"+",
  "\"<tr style = 'border-bottom: 1px solid #ccc;'><td><b>(choice1):</b></td><td>(definition1)</td></tr>\"+",
  "\"<tr style = 'border-bottom: 1px solid #ccc;'><td><b>(choice2):</b></td><td>(definition2)</td></tr>\"+",
  "\"<tr><td><b>(choice3):</b></td><td>(definition3)</td></tr>\"+",
  "\"</table></span></div>\","
) %>% 
  clipr::write_clip()

glue_data(
  me_data %>% 
    mutate(img = as.numeric(img)) %>% 
    arrange(img) %>% 
    mutate(
      row = 1:n(),
      answer_raw = case_when(answer_js == 0 ~ choice0,
                             answer_js == 1 ~ choice1,
                             answer_js == 2 ~ choice2,
                             answer_js == 3 ~ choice3)
      ),
  .open = "(", .close = ")",.na = "", .sep = "\n",
  '{stimulus: "<image src=" + img_files[(row-1)] + " width = \'500px\'><br><br>", prompt: me_prompt + "<br>image: (img), answer: (answer_raw)<br><br>" + prompts[(row-1)], choices: ["(choice0)","(choice1)","(choice2)","(choice3)"], data: {answer: "(answer)", answer_js: (answer_js), gender: "(gender)", img: (img)}},'
) %>% 
  clipr::write_clip()
