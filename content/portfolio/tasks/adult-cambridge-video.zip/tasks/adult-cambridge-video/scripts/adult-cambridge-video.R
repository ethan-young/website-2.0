# Packages ----------------------------------------------------------------
library(tidyverse)
library(readxl)
library(glue)

# Copy Images -------------------------------------------------------------
# walk(list.files(path = "../Mind in the Eyes/Resized_RME_JPEG_files", pattern = ".jpg$",full.names = F), function(x){
#   file.copy(paste0("../Mind in the Eyes/Resized_RME_JPEG_files/", x),to = paste0("img/", x))
# })

# List Images -------------------------------------------------------------
cam_video <- data.frame(
  path  = list.files("video",full.names = T, pattern = "mp4$"),
  video = list.files("video",full.names = F, pattern = "mp4$") %>% str_remove(".mp4$")
) %>% 
  mutate(row = row_number())

paste0("\"",cam_video$path,"\"",",", collapse="\n") %>% clipr::write_clip()

# Read answers ------------------------------------------------------------
cam_video_answers <- read_csv("data/video-answers.csv") %>% 
  mutate(row = row_number()) %>% 
  full_join(cam_video, by = "row") %>% 
  mutate(
    answer    = str_remove(video,".*V"),
    answer_js = case_when(choice0 == answer ~ 0,
                          choice1 == answer ~ 1,
                          choice2 == answer ~ 2,
                          choice3 == answer ~ 3)
  )

# Word Definitions --------------------------------------------------------
cam_video_defs <- read_xls("data/definition-handout.xls",col_names = c("word","item","definition")) %>% 
  mutate(word = str_remove(word,"\\(.*") %>% str_trim(side = "both")) %>% 
  select(word, definition)

cam_video_data <- cam_video_answers %>% 
  gather(option, response, -starts_with("answer"), -item, -path, -row, -video) %>% 
  left_join(cam_video_defs, by = c("response" = "word")) %>% 
  arrange(row) %>% 
  mutate(option = str_replace(option,"choice","choice_")) %>% 
  separate(option, c("option","number")) %>% 
  gather(info, data,-item, -row, -path, -video, -answer, -answer_js, -option, -number) %>% 
  arrange(row) %>% 
  unite(info, info, number,sep="") %>% 
  spread(info, data) %>% 
  rename_at(vars(starts_with("response")),~str_replace(.,"response","choice")) %>% 
  mutate_at(vars(starts_with("definition")),~str_replace(.,"\'","\'")) %>% 
  mutate_at(vars(starts_with("definition")),~str_remove(.,",$")) %>% 
  mutate_at(vars(starts_with("definition")),~str_replace(.,"tounderstand","to understand"))

glue_data(
  .open = "(", .close = ")",.na = "",
  cam_audio_data,
  '{\n',
  '  stimulus: "(path)",\n',
  '  prompt: "<p>How is the speaker feeling?</p> <div class=\'tooltip\'>*definitions<span class = \'tooltiptext\'>(prompt)</span></div>" ,\n',
  '  choices: ["(choice0)","(choice1)","(choice2)","(choice3)"],\n',
  '  data: {answer: "(answer)", answer_js: (answer_js)}\n',
  '},'
)

glue_data(
  .open = "(", .close = ")",.na = "", .sep = "\n",
  cam_video_data,
  "\"<div class=\'tooltip\'>\" +",
  "\"*definitions*\" +",
  "\"<span class =  \'tooltiptext\'><table>\"+",
  "\"<tr style = 'border-bottom: 1px solid #ccc;'><td><b>(choice0):</b></td><td>(definition0)</td></tr>\"+",
  "\"<tr style = 'border-bottom: 1px solid #ccc;'><td><b>(choice1):</b></td><td>(definition1)</td></tr>\"+",
  "\"<tr style = 'border-bottom: 1px solid #ccc;'><td><b>(choice2):</b></td><td>(definition2)</td></tr>\"+",
  "\"<tr><td><b>(choice3):</b></td><td>(definition3)</td></tr>\"+",
  "\"</table></span></div>\","
) %>% 
  clipr::write_clip()

glue_data(
  cam_video_data,
  .open = "(", .close = ")",.na = "", .sep = "\n",
  '{sources: [video_files[(row-1)]], prompt: cam_video_replay + prompts[(row-1)], choices: ["(choice0)","(choice1)","(choice2)","(choice3)"], data: {answer: "(answer)", answer_js: (answer_js)}},'
)%>% 
  clipr::write_clip()
