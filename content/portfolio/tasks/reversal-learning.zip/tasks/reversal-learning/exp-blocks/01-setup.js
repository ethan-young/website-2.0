// timeline
var timeline = [];

//var participant_ID = {
//    type: 'survey-text',
//    questions: [
//      {
//        prompt: "Please enter your student ID number:",
//        value: '',
//        rows: 1,
//        columns: 7,
//      }
//    ],
//    data: {variable: 'ID'}
//};

//timeline.push(participant_ID);